function br(){
    document.write("<br>");
}

function hr(){
    document.write("<hr>");
}

function dw(str){
    document.write(str);
}